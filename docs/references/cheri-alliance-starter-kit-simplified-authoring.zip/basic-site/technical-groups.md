---
layout: index
title: Technical groups
permalink: /working-groups/technical/
parent: /working-groups/
listing:
  columns: 2
  title: In this section
where-next:
  action: Start exploring
  url: /build/
related-pages:
  - action: Browse resources
    url: /resources/
  - action: Explore groups
    url: /working-groups/
  - action: Get in touch
    url: /contact/
---

Explore sample areas for focused CHERI collaboration.

## Find a useful starting point

Different perspectives make technical conversations more useful. Application developers, platform engineers, researchers and people responsible for products often approach the same problem with different questions. Bringing those questions together helps a group identify shared priorities and describe the work in terms that others can follow.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.
