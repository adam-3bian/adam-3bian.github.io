---
title: 'Sample: Introduction to CHERI'
thumbnail:
  src: /assets/images/placeholders/event-thumbnail.svg
  alt: Landscape placeholder for a CHERI Alliance event image
date: 2026-09-02
---

A fictional CHERI community event exploring memory safety, practical questions and shared learning.

## Session overview

![Placeholder for a sample CHERI event]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

This sample event brings together an introductory discussion and a practical set of questions about CHERI. It is a fictional programme, with example dates, and does not announce a real event or confirm any speakers. Its subjects provide a clear route from an overview into further learning.

Keep conceptual explanations close to the examples that make them concrete. A diagram, a short exercise and a few carefully chosen questions can make a new topic easier to discuss. Readers should be able to move from the broad idea to a more detailed reference when they are ready.

Different perspectives make technical conversations more useful. Application developers, platform engineers, researchers and people responsible for products often approach the same problem with different questions. Bringing those questions together helps a group identify shared priorities and describe the work in terms that others can follow.

## Discussion topics

![Placeholder for a CHERI workshop discussion]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

The discussion starts with the questions participants bring to the subject. A shared example keeps the conversation focused and gives people with different levels of experience a way to contribute.

- Memory-safety concepts and useful terminology.
- Choosing a small evaluation task.
- Recording a baseline and interpreting observations.
- Finding guides and maintained references.
- Connecting questions with community discussions.

Make room for both successful results and open questions. Notes about build steps, dependencies, tests and debugging can be as useful as a final demonstration. A focused next step gives the evaluation a clear conclusion and a practical route back into the wider CHERI community.

## Continue learning

![Placeholder for CHERI event follow-up resources]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

[Browse sample speakers]({{ '/speakers/' | relative_url }}) or [continue with the guides]({{ '/resources/guides/' | relative_url }}).
