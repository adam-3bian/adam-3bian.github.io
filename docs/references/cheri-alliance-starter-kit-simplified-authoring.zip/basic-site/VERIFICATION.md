# Verification for this delivery

## Current revision: people/person and dark-mode contrast

Completed source and colour checks on 7 October 2026:

- Parsed all 53 front-matter files and the YAML configuration/data files.
- Checked that every referenced layout and include exists, and that layout
  inheritance has no cycles.
- Compared all 40 source-derived page routes and parent relationships with
  the supplied ZIP. Public routes and hierarchy are unchanged, including
  `/speakers/` and all three existing profile URLs.
- Confirmed that the list uses `people` and `site.people`, and all three
  profiles inherit `person` through the `people` collection defaults.
- Confirmed that the moved profile files and the renamed detail template are
  byte-identical to their originals. Alphabetical listing order, portrait
  rendering and redirect filtering remain in the list/detail templates.
- Compared the collection configuration with the original after normalising
  the internal rename; all other configuration values are unchanged.
- Confirmed that the light-theme settings, image assets, JavaScript,
  navigation data, Gemfile and lockfile are unchanged.
- Updated the existing native site checker to select directory checks by
  `people`/`members` layout, independent of the public directory URL.

## Dark-mode colour checks

The main content fill is now `rgba(#07151e, 0.90)`, up from 40% opacity.
The dark hero keeps `#1e5e7a` with opacity subtly reduced from 64% to 60%.
Compared with the previous delivery, the only styling change is this hero
opacity. Original card and onward-link fill settings, including hover/focus
states, are retained. Body and muted text colours are unchanged.

Calculated contrast over every distinct pixel colour in the retained dark
WebP tile, compositing its pixel alpha, watermark opacity, page background
and the content fill. These are source-colour calculations, not measurements
from a browser screenshot.

| Surface | Previous white text | Updated white text | Updated muted text |
| --- | --- | --- | --- |
| Main content | 11.42:1 | 17.53:1 | 12.02:1 |

The body-text, muted-text and hover-link contrast calculations for content
remain valid because its colours have not changed in this correction.
The watermark asset and its global opacity are unchanged; the denser content
background reduces how strongly it shows beneath text.

## Verification limits

Ruby, Bundler and Jekyll are not installed in this execution environment,
so native builds and the Ruby site checker were not rerun. Supported browser
preview tooling is also unavailable; rendered appearance and browser
interactions remain unverified for this revision. No new build dependency was
introduced.

The supplied ZIP records earlier native root/prefixed builds and authoring
fixture checks. Those results belong to the preceding revision and are not
claimed as fresh verification of this delivery.

## Reproduce the normal build

From `basic-site/`, with Ruby and Bundler installed:

```sh
bundle install
bundle exec ruby scripts/check_redirects.rb
bundle exec jekyll build --destination _site
bundle exec ruby scripts/check_site.rb _site

bundle exec ruby scripts/check_redirects.rb /cheri-preview
bundle exec jekyll build --safe --baseurl /cheri-preview --destination _site
bundle exec ruby scripts/check_site.rb _site /cheri-preview
```

Check the dark home page and the Speakers list/detail pages at 375, 768, 1024
and 1440px. Confirm body readability over the patterned background, card
hover/focus states, alphabetical profiles and square detail portraits.
