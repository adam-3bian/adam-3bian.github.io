---
layout: forms
title: Markup examples
parent: /resources/
form:
  id: example-form
  title: Rendered form example
  demo: 'Demonstration form: no submission service is connected. Nothing will be sent.'
  fields:
    - name: name
      label: Your name
      size: half
      required: true
      autocomplete: name
      placeholder: Full name
    - name: email
      label: Email address
      type: email
      size: half
      required: true
      autocomplete: email
      placeholder: you@example.org
      help: Use an address where we can reply.
    - name: topic
      label: Enquiry topic
      type: select
      required: true
      placeholder: Choose a topic
      options:
        - label: Membership
          value: membership
        - label: Technical enquiry
          value: technical
    - name: message
      label: Your message
      type: textarea
      required: true
      placeholder: Tell us what you would like to discuss.
where-next:
  action: Explore resources
  url: /resources/
related-pages:
  - url: /discover/
  - action: View the form
    url: /contact/
  - title: Kramdown syntax
    action: Read the documentation
    url: https://kramdown.gettalong.org/syntax.html
    target: _blank
---

Use these examples to write and configure a page in this starter kit.

This is the single authoring examples page. Its source is `markup-examples.md`.
The hero above, images and table below, form near the end, and onward links all
use the same components as the rest of the site.

- [Complete page front matter](#complete-page-front-matter)
- [Headings and text](#headings-and-text)
- [Left, right and full-width images](#left-right-and-full-width-images)
- [Scrollable tables](#scrollable-tables)
- [Heroes and carousels](#heroes-and-carousels)
- [Where next and related pages](#where-next-and-related-pages)
- [Forms](#forms)
- [Internal and external links](#internal-and-external-links)
- [Redirects](#redirects)
- [Collections, hierarchy and site settings](#collections-hierarchy-and-site-settings)

## Complete page front matter

Write the introduction as the first Markdown paragraph. The layout shows it
once below the title, in the hero or ordinary heading, and uses its plain text
for search metadata. Bold text, emphasis and links work in that paragraph.
Continue the body with headings, images and further paragraphs. This also
works on form pages; additional Markdown appears above the form.

For a normal root page such as `getting-involved.md`, this is enough:

{% raw %}
```markdown
---
title: Getting involved
---

Find a useful starting point for your next conversation.

## Choose a route

Write the rest of the page here.
```
{% endraw %}

The defaults select `page`, the light theme, a hero and Home as the parent.
The filename supplies `/getting-involved/`. Keep an explicit `permalink` for
nested routes or a URL that differs from the filename, and `parent` for its
place in the hierarchy. Do not repeat inherited values.

A page needing more options can keep them grouped:

{% raw %}
```markdown
---
title: Getting involved
permalink: /about/getting-involved/
parent: /about/
hero:
  size: large
where-next:
  url: /working-groups/
  action: Explore groups
  image:
    src: /assets/images/placeholders/landscape-left.svg
    alt: Working together in the CHERI community
related-pages:
  - url: /membership/
  - title: CHERI Alliance
    url: https://cheri-alliance.org/
    target: _blank
---

Find a useful starting point for your next conversation.

## Choose a route

Write the rest of the page here.
```
{% endraw %}

Use two spaces per YAML level. Quote text containing `: ` and use actual
booleans (`true`/`false`, without quotes). Keep related properties beneath
`hero`, `thumbnail`, `slider`, `listing`, `form`, `where-next` and `related-pages`.

Internal onward links infer their title from the destination page. Only
supply `title` for different wording or an external destination. `action`
defaults to Continue for Where next and Explore for related pages.

No `description` or `summary` is needed. An explicit `description` remains
available for different search metadata; legacy `summary` is still supported
as a visible heading override. If the body starts with a heading or image,
there is no automatic introduction. Missing metadata falls back to the site
description. Use an ordinary opening paragraph for automatic extraction.

Use `hero: false` for an ordinary heading, `theme: dark` for the dark palette,
and `image-overlay: false` to disable image enlargement. Home alone is dark
in the sample site.

Image properties stay together beneath `image` or `thumbnail`. `fit` defaults
to `cover`; use `contain` to show an entire image inside a fixed frame.
`position` defaults to `center`, with `left` and `right` available.

## Headings and text

The layout supplies the page's H1. After the opening paragraph, start section
headings at H2 (`##`) and use H3/H4 for subsections. Keep a blank line between
paragraphs and around lists.

{% raw %}
```markdown
## Plan your next step

Write a short introduction with **important words** or *gentle emphasis*.

### Choose a subject

- Record the context.
- Identify the next question.

#### Keep a useful record

1. Describe your starting point.
2. Link to the relevant resources.

> A quotation or short callout belongs in a blockquote.

[Browse resources]({{ '/resources/' | relative_url }}).
```
{% endraw %}

### Example subsection

This is a rendered H3 followed by **bold text**, *emphasis* and `inline code`.

#### Example detail

This is a rendered H4. Heading levels express the structure of the content.
Kramdown creates heading IDs for links; an explicit ID such as
`## Plan your next step {#plan}` stays stable when you change the title.

## Left, right and full-width images

These are ordinary Markdown images with Kramdown attributes directly after
the closing parenthesis. Keep the asset path inside `relative_url` so it also
works when the site is hosted in a repository subdirectory.

### Left image

{% raw %}
```markdown
![A discussion about memory safety]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

Write the paragraphs that should flow beside the image here.
```
{% endraw %}

![A discussion about memory safety]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

On desktop, this image sits on the left and the text flows beside it. Begin
with the subject of the image and explain why it belongs in this section.
Alternative text should convey what a reader needs to understand, rather than
repeat a filename.

Use enough prose to establish the context and explain the next step. The
shared styles limit floated images to 40% of the content width, with a maximum
width of 28rem and height of 20rem. On smaller screens, the image and text stack.

### Right image

{% raw %}
```markdown
![Questions for a platform evaluation]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

Write the paragraphs that should flow beside the image here.
```
{% endraw %}

![Questions for a platform evaluation]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

This image uses the same dimensions and responsive rules, aligned to the
right. The next section heading clears the float automatically. There is no
need to add empty paragraphs or manual line breaks to position it.

The alignment class is sufficient for rendering. `width` and `height` are
optional: add the real source dimensions when you want to reserve space before
the image loads, especially for raster images. The browser still scales the
image responsively. The content script adds lazy loading automatically when
JavaScript runs; images remain usable without JavaScript. An explicit
`loading="eager"` or `loading="lazy"` is respected.

### Full-width image

{% raw %}
```markdown
![Overview of a learning journey]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}
```
{% endraw %}

![Overview of a learning journey]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

Full width means the width of the content area. Images keep their proportions.
Click these body images to enlarge them; add `.no-zoom` alongside the alignment
class to opt out. The expanded image fills the available viewport while keeping
its proportions, a small outer margin, its caption and an accessible Close
button. Escape closes it and restores focus. Carousel images always follow
the slide’s link.

## Scrollable tables

Write a normal Markdown table. No special HTML wrapper is needed. On a narrow
screen, swipe or scroll horizontally inside the table to reach the right-hand
columns. With JavaScript enabled, overflowing tables can also receive keyboard
focus so the arrow keys can scroll them. The CSS scrolling fallback works
without JavaScript.

{% raw %}
```markdown
| Component | Image source | Fit | Source size | Destination |
| --- | --- | --- | --- | --- |
| Body image | full-width.svg | Natural proportions | 1600 × 900 | Image enlargement |
| Carousel | slider.svg | cover | 1920 × 1080 | Slide URL |
| News | news-thumbnail.svg | cover | 1600 × 900 | News page |
| Speaker | speaker-portrait.svg | cover | 800 × 800 | Speaker page |
| Event | event-thumbnail.svg | cover | 1600 × 900 | Event page |
| Member logo | member-logo.svg | contain | 800 × 800 | Member page |
{: aria-label="Image configuration examples"}
```
{% endraw %}

| Component | Image source | Fit | Source size | Destination |
| --- | --- | --- | --- | --- |
| Body image | full-width.svg | Natural proportions | 1600 × 900 | Image enlargement |
| Carousel | slider.svg | cover | 1920 × 1080 | Slide URL |
| News | news-thumbnail.svg | cover | 1600 × 900 | News page |
| Speaker | speaker-portrait.svg | cover | 800 × 800 | Speaker page |
| Event | event-thumbnail.svg | cover | 1600 × 900 | Event page |
| Member logo | member-logo.svg | contain | 800 × 800 | Member page |
{: aria-label="Image configuration examples"}

The attribute line immediately after the table gives the scrollable region a
useful accessible label. For column alignment, use `:---`, `:---:` or `---:`
in the separator row.

## Heroes and carousels

Heroes are enabled by default and reuse `title` and the opening Markdown paragraph. Their optional
settings are `size` and `title`; only supply a title override when it differs
from the page title. `size: large` uses the prominent Home treatment; omitting
size uses the standard treatment. Dates and an optional news byline appear
between the title and introduction. Set `hero: false` for a normal heading instead.

Add this `slider` map to the page's front matter. It renders as a separate
section below the hero. See the live carousel on [Home]({{ '/' | relative_url }}).

{% raw %}
```yaml
slider:
  title: Explore CHERI
  autoplay: true
  slides:
    - title: Discover CHERI
      text: Explore capabilities and memory safety.
      image:
        src: /assets/images/placeholders/slider.svg
        alt: Introduction to CHERI
        fit: contain
      action: Discover CHERI
      url: /discover/
    - title: CHERI Alliance
      text: Visit the Alliance website.
      image:
        src: /assets/images/placeholders/slider.svg
        alt: CHERI Alliance community
        fit: cover
        position: right
      action: Visit the website
      url: https://cheri-alliance.org/
      target: _blank
      rel: noopener noreferrer
```
{% endraw %}

Every slide should have a `url`. Clicking its image, title, text, action or
background follows that URL; the whole slide is one keyboard-accessible link.
Unicode `●` dot selectors below the slide let readers choose another slide.
Each is a native button with an accessible slide label; the current dot is
larger and uses the main text colour. The dots have 44px minimum targets for
touch and keyboard use.
There is no carousel image zoom.
The CTA uses the same text-and-arrow styling as the site's other card links.

The carousel sits outside the hero, with equal-width image and text columns on
desktop and a single stacked column on mobile. Unicode dot selectors are centred
below the slide. If `hero: false`, the carousel follows the body so the page's
ordinary heading comes first.
`interval` is in milliseconds, with a minimum of 3000. Home and the example above
advance every five seconds. Hovering over the carousel and clicking a dot
selector do not stop playback; selecting a slide starts a fresh five-second
interval. Playback waits while a slide link has keyboard focus or the tab is
hidden, then resumes automatically. Reduced-motion preferences disable autoplay;
playback resumes if that preference is turned off. Set `autoplay: false` or omit
it for manual selection. If you omit `interval`, it defaults to 5000 milliseconds.
Without JavaScript, the first slide's complete link remains usable.

## Where next and related pages

Both are optional and retain their nested structure. Internal destinations
supply their own page titles; add a title only to override that wording.
Where next uses Continue as its default action; related pages use Explore.
`target` and `rel` remain available, and `_blank` adds the safe rel values.

{% raw %}
```yaml
where-next:
  url: /discover/
  image:
    src: /assets/images/placeholders/landscape-left.svg
    alt: Introduction to CHERI
related-pages:
  - url: /membership/
  - title: CHERI Alliance on GitHub
    action: View repositories
    url: https://github.com/CHERI-Alliance
    target: _blank
```
{% endraw %}

Collection-wide onward links live in `_config.yml`, so individual profiles,
events and posts need not repeat them. Override them on a page when needed;
`where-next: false` or `related-pages: []` hides the inherited component.

## Forms

Select `layout: forms` and group the fields beneath `form`. Put the page
introduction and any further instructions in Markdown, after the front matter.
The opening paragraph becomes the heading introduction; subsequent content
appears before the fields. There is no separate `form.intro` or description.

{% raw %}
```markdown
---
layout: forms
title: Contact the Alliance
form:
  title: Send an enquiry
  fields:
    - name: name
      label: Your name
      size: half
      required: true
      autocomplete: name
    - name: email
      label: Email address
      type: email
      size: half
      required: true
      autocomplete: email
    - name: topic
      label: Enquiry topic
      type: select
      required: true
      options:
        - label: Membership
          value: membership
        - label: Technical enquiry
          value: technical
    - name: message
      label: Your message
      type: textarea
      required: true
---

Contact the Alliance about membership or technical collaboration.

Include enough detail to help us route your enquiry.
```
{% endraw %}

Fields stack on mobile. `size: half` shares a desktop row; omitted sizes and
`size: full` span both columns. `type` defaults to text, `required` to false,
and textarea `rows` to 6. Other supported types are email, tel and select.
Keep names unique. `placeholder`, `help` and `autocomplete` remain optional.
Select options group their visible `label` and submitted `value`.

The form ID defaults to `enquiry-form`, its method to `post` and its button
label to Send enquiry. Override `id`, `method`, `submit` or `demo` only when
needed. An omitted or empty `action` renders a disabled, non-submitting demo,
including without JavaScript. Set `action` to a real form endpoint to receive
submissions. GitHub Pages itself cannot process forms; the receiving service
handles delivery and confirmation.

## Internal and external links

Yes: Kramdown supports external-link attributes. Keep the attribute list
immediately after the link, on the same line.

{% raw %}
```markdown
[Local resources]({{ '/resources/' | relative_url }})

[Choose a platform]({{ '/build/#choose-a-platform' | relative_url }})

[CHERI Alliance](https://cheri-alliance.org/){: target="_blank" rel="noopener noreferrer"}
```
{% endraw %}

[CHERI Alliance](https://cheri-alliance.org/){: target="_blank" rel="noopener noreferrer"}
is a rendered external link. `target="_blank"` opens a new tab/window according to
the visitor’s browser settings; `rel="noopener noreferrer"` isolates it from the
opener. These attributes work without JavaScript.

Use the same attribute names beside `url` in front matter and navigation data:

{% raw %}
```yaml
- title: CHERI Alliance
  url: https://cheri-alliance.org/
  target: _blank
  rel: noopener noreferrer
```
{% endraw %}

This works in menus, social links, sliders, Where next, related pages, listing
cards and Subscribe. A `_blank` target also adds missing `noopener`/`noreferrer`
tokens without discarding other `rel` values, such as `nofollow`.

Omit both attributes for ordinary internal links. The content script retains
its fallback that opens unmarked off-site HTTP(S) links in a new tab. An
explicit `target: _self` (or Kramdown `target="_self"`) is respected, as are named
targets. There is no `external` front-matter flag or required CSS class.

## Redirects

Manage redirects centrally in `_redirects/`, with one Markdown file per source
path. The collection is configured to output HTML, and its defaults omit the
site shell, navigation parent and sitemap entry. Redirects never appear in
content listings. Only two front-matter fields are needed.

For `_redirects/examples.md`:

{% raw %}
```yaml
---
permalink: /examples/
redirect_to: /markup-examples/
---
```
{% endraw %}

For `_redirects/alliance-website.md`:

{% raw %}
```yaml
---
permalink: /alliance-website/
redirect_to: https://cheri-alliance.org/
---
```
{% endraw %}

Both examples are included in this kit. [Open /examples/]({{ '/examples/' | relative_url }})
returns to this page; [open /alliance-website/]({{ '/alliance-website/' | relative_url }})
redirects to the Alliance website.

`permalink` is the old/source path. Use a root-relative directory URL ending in
`/`, or an explicit `.html` path. `redirect_to` is a root-relative internal path
or a complete HTTP(S) URL. Internal destinations may include a query or fragment.
Do not add `baseurl` to either field; the enabled `jekyll-redirect-from` plugin
adds the deployment prefix to internal destinations and leaves external URLs
unchanged. Redirects navigate the current tab.

Run this before building, using the same optional baseurl as the build:

```sh
bundle exec ruby scripts/check_redirects.rb
bundle exec ruby scripts/check_redirects.rb /cheri-preview
```

The checker rejects duplicate source/output paths, collisions with real pages
or assets, missing internal destinations and redirect loops. It also checks
legacy `redirect_from` aliases if you retain any. The existing `/examples/`
alias has moved into the collection; do not define it in both places.

These are **static HTML redirects**, using the existing plugin’s refresh page,
canonical destination and fallback link. They do not set HTTP 301/302 status
codes; configure those at the host if needed. `redirect_to` and `redirect_from`
retain their plugin-required underscores.

## Collections, hierarchy and site settings

The template names match each content type:

| Content | List layout | Detail layout | Detail source | Default order |
| --- | --- | --- | --- | --- |
| People | `people` | `person` | `_people/` | Alphabetical |
| Events | `events` | `event` | `_events/` | Earliest date first |
| News | `news` | `post` | `_posts/` | Latest date first |
| Members | `members` | `member` | `_members/` | Alphabetical |

Person profiles live in `_people/` and inherit `layout: person`. Their list
uses `layout: people` and reads `site.people`. The sample list still has the
public title Speakers and lives at `/speakers/`; the collection's permalink
keeps existing profile URLs under `/speakers/` too.

A directory needs only its layout and title. The filename supplies its route;
its template chooses the collection, ordering and card style:

{% raw %}
```markdown
---
layout: events
title: Events
---

Workshops and community sessions.
```
{% endraw %}

The detail layout, parent and shared onward links are inherited from the
collection defaults in `_config.yml`. A detail file needs its title, thumbnail,
any genuine metadata and Markdown content. For `_events/technical-workshop.md`:

{% raw %}
```markdown
---
title: Technical workshop
thumbnail:
  src: /assets/images/placeholders/event-thumbnail.svg
  alt: A technical workshop
date: 2026-11-18
end-date: 2026-11-19
---

A practical workshop exploring CHERI evaluation.

## Programme

Write the event details here.
```
{% endraw %}

`end-date` is optional. News takes its date from `_posts/YYYY-MM-DD-slug.md`.
News and event thumbnails use 16:9 frames; speaker and member thumbnails use
square frames. Member logos normally use `fit: contain`. Image dimensions
aren't needed for these fixed frames.

The `person` layout automatically renders its shared thumbnail in a square
body frame after the first section heading, or before the body if there is no
section heading. It supports the thumbnail's fit/position settings and image
enlargement. No portrait HTML needs to be copied into a person's Markdown.

`parent` points to an existing page URL and supplies breadcrumbs. Root pages
inherit `/`; collection details inherit their directory. Keep explicit parents
for deeper pages and `parent: false` for a page without ancestors. Use
`nav-title` for a shorter breadcrumb label and avoid cycles.

A page with `layout: index` lists its children automatically. It keeps the
hierarchy independent of source-file location:

{% raw %}
```markdown
---
layout: index
title: Technical groups
permalink: /working-groups/technical/
parent: /working-groups/
listing:
  title: In this section
  columns: 2
---

Explore focused areas for collaboration.
```
{% endraw %}

`listing.columns` can adjust the desktop grid on named directories, news and
indexes. The generic `list` layout remains available for a custom collection
with grouped `listing.collection`, `sort`, `order`, `compact` and `action`
options. Indexes derive children from `parent` without a collection setting.

### Optional news author and company

Both fields are optional and independent. They appear after the date on a news
post, with a separator only when both are present. Omit either field completely
when it is unknown; do not add empty placeholders. The byline appears on the
detail page. Demo news posts use Dan Sullivan, Adam Finney and Mike Eftimakis.

{% raw %}
```markdown
---
title: A community update
thumbnail:
  src: /assets/images/placeholders/news-thumbnail.svg
  alt: A community discussion
author: Dan Sullivan
company: Example company
---

A short introduction to the article, written in Markdown.
```
{% endraw %}

Save the post as `_posts/YYYY-MM-DD-slug.md`; the filename supplies its date.
The hero and normal-heading layouts both support the optional byline.

In `_data/navigation.yml`, nest child items under `links`. A parent link and its
submenu disclosure remain separate controls. Header mega-menus use
`type: megamenu`, `columns` and a list of `subcategories`, each with `title` and
`links`. In `_config.yml`, `subscribe` controls the shared call to action:

{% raw %}
```yaml
subscribe:
  enabled: true
  title: Stay connected with CHERI
  action: Subscribe
  url: /subscribe/
```
{% endraw %}

Set `enabled: false` to hide it globally, or `subscribe: false` in a single
page's front matter. For a signup service in a new tab, set an HTTPS `url`,
`target: _blank` and `rel: noopener noreferrer` in the site configuration.

For the complete syntax, see [Kramdown's documentation](https://kramdown.gettalong.org/syntax.html){: target="_blank" rel="noopener noreferrer"}
and [Jekyll's redirect plugin](https://github.com/jekyll/jekyll-redirect-from){: target="_blank" rel="noopener noreferrer"}.

### Colours and the body watermark

Theme settings live in `_sass/settings.scss`. Light-theme section colours use
variables such as these; the `$theme-dark` map contains the corresponding dark
values:

```scss
$colour-page: rgba(#ffffff, 0.46);
$colour-hero: rgba(#8ebed4, 0.66);
$colour-card: rgba(#74a7bf, 0.62);
$colour-card-hover: rgba(#6b9db7, 0.72);
$colour-subscribe-band: rgba(#062c3b, 0.74);
$colour-subscribe-card: rgba(#c4e1ef, 0.76);
$colour-subscribe-card-hover: rgba(#aed4e7, 0.80);
$colour-subscribe-text: #08202b;
$colour-watermark: rgba(#125770, 0.32);
$colour-link-hover: #721515;
```

The opacity argument ranges from `0` (transparent) to `1` (solid). It applies
only to the background; text and controls remain opaque. Keep enough contrast
with the patterned body beneath the section. The dark Subscribe band keeps
its own background.

Cards and heroes use richer translucent fills without decorative borders or
shadows. Their colours distinguish them from the page without hiding the
honeycomb. Subscribe uses its own translucent pale card colours and dark
`subscribe-text` over the translucent dark `subscribe-band`, with a visible
keyboard focus outline. These values live in the theme settings; no extra
front matter is needed.

The background uses the logo’s rounded outer hexagon in a composed honeycomb.
Staggered rows, diagonal tonal ribbons and larger anchor cells make it work
as a standalone background. Every cell has a transparent centre and an outline
made from 1px horizontal lines separated by 1px gaps, clipped inside the
original contour. Native-size display preserves the 1px pixel spacing.
Cells remain separated and retain the original proportions. The logo files
are unchanged; there is no grain layer.

The live background uses separate lossless WebP images for light and dark
mode; the editable `hexagons.svg` source is retained. It does not load the SVG
or use a CSS mask. The pattern tiles seamlessly on both axes at native size,
with the 1px-on, 1px-off rows baked into the WebPs.

Adjust the alpha in `watermark` to change its strength; `0` hides it. After
changing its RGB colour or the SVG geometry, regenerate the WebP files with
`node scripts/render_backgrounds.cjs` (the optional `sharp` dependency and
full instructions are in the README). Section opacity controls how much
detail shows through without changing text opacity. No page front matter is
needed for these settings.

Ordinary text links turn red on hover. `link-hover` uses a lighter red in dark
mode to remain readable. Navigation links, cards, buttons and image links keep
their established behaviour.
