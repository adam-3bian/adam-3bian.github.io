---
title: Taking part
permalink: /working-groups/participation/
parent: /working-groups/
where-next:
  action: Start exploring
  url: /build/
related-pages:
  - action: Browse resources
    url: /resources/
  - action: Explore groups
    url: /working-groups/
  - action: Get in touch
    url: /contact/
---

Bring a clear question, a useful observation or a practical contribution to a CHERI discussion.

## Start with a clear question

![Placeholder for taking part]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

Different perspectives make technical conversations more useful. Application developers, platform engineers, researchers and people responsible for products often approach the same problem with different questions. Bringing those questions together helps a group identify shared priorities and describe the work in terms that others can follow.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

Progress can take several forms: an improved explanation, a reproducible experiment, a useful review or a clearer understanding of a limitation. Sharing the reasoning behind a decision makes that progress easier to build on. The most helpful next contribution is often a small one that another person can use.

## Build a useful record

![Placeholder for CHERI learning and evaluation]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

Learning is easier to continue when each session leaves a useful record. Keep a short glossary, note the references that helped and capture the questions that remain. These small resources support the next conversation and help connect individual learning with shared work across the CHERI ecosystem.

## Take the next step

![Placeholder for the next CHERI learning step]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

[Return to the section index]({{ '/working-groups/' | relative_url }}) or [contact the Alliance]({{ '/contact/' | relative_url }}).
