# Source notes

## Design and structure

The supplied `basic-site-news-github-pages` starter provides the Jekyll/Liquid/Kramdown/SCSS architecture, flat visual style, reusable layouts, cards, column utilities and onward-navigation components.

[The CHERI Alliance reference site](https://cheri-alliance.github.io/) informed the subjects and routes into discovery, building, resources, the Alliance and community updates. Its page copy was not imported. All demonstration prose and SVG placeholders in this kit were written for this revision.

## Official logo assets

The two matching SVG masters were extracted byte-for-byte from the [official CHERI Alliance logo pack](https://cheri-alliance.org/cheri-alliance-logo-pack/), linked from the [press resources page](https://cheri-alliance.org/news/press/).

| Local asset | Original archive entry | SHA-256 |
| --- | --- | --- |
| `assets/images/brand/logo-blue.svg` | `Logo-CHERI-RGB-blue.svg` | `e5e71b65000e93a27de232bd71946cb69bb382742e8b88aa5fd9bebc755f8d4d` |
| `assets/images/brand/logo-white.svg` | `Logo-CHERI-RGB-white.svg` | `300942a3af639c38858efc8301343d6fa5d974962e1d7fc2fd9b9fb14c555f62` |

Both masters have the same `0 0 326.13 112.08` viewBox. They retain their original paths, colours and proportions. They are served as external image files, with no redraw, colour filter or edited SVG markup. The blue master is used on light pages and the white master on the dark home page.

The CHERI name and logo remain the trademarks of the CHERI Alliance. [Branding and trademark information](https://cheri-alliance.org/legal-and-policies/trademark/) remains available from the Alliance.

## Sample content

The kit contains no real member affiliations, speaker biographies, endorsements or factual announcements. Dates, titles and profiles marked as samples demonstrate the page structures. Replace them with approved content before publishing.

The previously imported photographs and factual article/profile content have been removed from this starter-kit revision. Its illustrative assets are the eight local SVG placeholders documented in the README, the two official logo masters, and the three footer icons described below.

## Footer social icons

The local [LinkedIn](https://icons.getbootstrap.com/icons/linkedin/),
[Mastodon](https://icons.getbootstrap.com/icons/mastodon/) and
[Slack](https://icons.getbootstrap.com/icons/slack/) SVG paths come from Bootstrap
Icons. Their paths and square viewBoxes are preserved, their display dimensions
are 24 × 24, and their fill matches the light footer text. The MIT license is
included at `assets/images/social/LICENSE.txt`. These are standalone assets;
the site does not load Bootstrap CSS, JavaScript or an icon font.

LinkedIn and Mastodon destinations follow the social links in the Alliance's
[CHERIoT announcement](https://cheri-alliance.org/cheriot-1-0-specification-released/).
Slack leads to the University of Cambridge's public
[CHERI-CPU Slack joining page](https://www.cl.cam.ac.uk/research/security/ctsrd/cheri/cheri-slack.html).
All three destinations are editable under `social` in `_data/navigation.yml`.

## Theme colours

The reference site's [published branding guidelines](https://cheri-alliance.org/wp-content/uploads/2025/08/CHERI-Branding-guidelines.pdf)
and [live theme CSS](https://cheri-alliance.org/wp-content/uploads/elementor/css/post-7.css)
provide blue `#135771`, beige `#FDECE3`, red `#BA1E1E`, white `#FFFFFF`,
charcoal `#373636` and the site's cool grey `#D1D6DF`. The kit uses these
colours with derived blue shades for surfaces, hover states, dark mode and the
footer. Those derived shades are implementation choices, not additional
official brand colours. The original logo masters remain unmodified.

The news and event placeholders are 1600 × 900, matching their 16:9 listing
frames. The 1920 × 1080 carousel placeholder is named `slider.svg` and labelled
“Slider image”. All placeholder labels now show aspect ratios rather than
pixel sizes, while their source dimensions and viewBoxes keep those ratios.

## Decorative background

The background is a composed honeycomb with staggered rows, soft diagonal
tonal ribbons and four larger anchor cells. All cells are hollow outlines made
from 1px horizontal lines with 1px gaps. Their centres remain transparent,
with quieter tonal detail through the middle. This arrangement works as a
standalone backdrop as well as through translucent sections.

`assets/images/background/hexagons.svg` uses the outermost contour from the
logo master, including its rounded corners and original proportions. It does
not include the interior artwork or lettering. The patterned outline is
clipped inside that contour, so its strokes do not enlarge the shape or fill
its centre. The layout is a seamless 1518 × 1926 tile, with wrapped copies
of edge-crossing cells and periodic tonal bands. The four larger anchors and
the original contour are retained. The source is rasterised into lossless light/dark
WebP images. The exporter clears alternate pixel rows in the alpha channel,
baking 1px horizontal lines and 1px transparent gaps into each file. CSS uses
the native image size, centred and repeated on both axes, with no stripe overlay.
The even tile height keeps the line/gap rhythm continuous across vertical joins.
Both official logo files remain unchanged. Grain and its
asset/settings have been removed.

The live background uses `hexagons-light.webp` and `hexagons-dark.webp` as
ordinary CSS background images, with separate strengths for light and dark
themes. The SVG is retained only as the editable source; the stylesheet does
not reference it or use CSS masking. Translucent section backgrounds carry
the honeycomb detail through the page, hero, cards and onward links.

Cards and heroes use richer translucent fills without decorative borders or
shadows. The Subscribe card and its independent dark band also let more of
the pattern through, while retaining clear separation in both themes. These adjustments
preserve both original logos. Speaker detail portraits
reuse the square directory asset through inline image markup. Form
front matter and templates do not use `intro`; introductions and instructions
are authored in Markdown and share the same paragraph handling as other pages.

## Official favicon

On 7 October 2026, the reference site's HTML identified
[its published favicon PNG](https://cheri-alliance.org/wp-content/uploads/2023/11/favicon.png)
as both its browser icon and touch icon. That 90 × 90 PNG is retained
byte-for-byte as `assets/images/brand/favicon-source.png`. It was resized
into 16, 32, 48 and 64px entries in `favicon.ico`; the artwork was not redrawn.
The two existing SVG logo masters remain unchanged.
