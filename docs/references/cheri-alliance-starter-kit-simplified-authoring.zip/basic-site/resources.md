---
layout: index
title: Resources
listing:
  columns: 2
  title: Explore resources
where-next:
  url: /build/
related-pages:
  - url: /discover/
  - url: /speakers/
  - url: /working-groups/
---

Find a route through CHERI guides, presentations and further reading.

## Find your starting point

![Placeholder for CHERI learning resources]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

Consider the purpose of each resource before following a long sequence of links. An overview may establish vocabulary, while a guide may focus on a particular task. Presentations can provide another explanation of the same subject and introduce questions worth returning to during an evaluation.

Bring notes from practical work back to the reading. An unfamiliar term, a surprising result or an incomplete instruction can suggest the next reference to consult. Keeping those questions alongside the source material makes the collection more useful for both individual learning and group discussion.

## Read with a question in mind

![Placeholder for technical reading and notes]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

A route into CHERI can begin with the concepts, a practical example or a conversation with the community. Different readers need different levels of detail. A clear overview should establish the subject, explain the terminology and offer a useful next step without assuming that everyone has the same background.

Keep conceptual explanations close to the examples that make them concrete. A diagram, a short exercise and a few carefully chosen questions can make a new topic easier to discuss. Readers should be able to move from the broad idea to a more detailed reference when they are ready.

Learning is easier to continue when each session leaves a useful record. Keep a short glossary, note the references that helped and capture the questions that remain. These small resources support the next conversation and help connect individual learning with shared work across the CHERI ecosystem.

## Connect reading with practice

![Placeholder for CHERI evaluation resources]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A useful CHERI evaluation begins with a clear question. A small application, a familiar library or a well-understood component gives a team something concrete to investigate. The aim is to understand the work involved, gather useful observations and decide which questions deserve a closer look.

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

[Start with a guide]({{ '/resources/guides/' | relative_url }}) or [browse presentations]({{ '/resources/presentations/' | relative_url }}).
