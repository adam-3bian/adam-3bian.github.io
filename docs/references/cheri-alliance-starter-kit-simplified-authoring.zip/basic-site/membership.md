---
title: Membership
where-next:
  url: /contact/
related-pages:
  - title: About the Alliance
    url: /about/
  - url: /members/
  - url: /working-groups/
---

Find the conversations, technical interests and community activities that matter to your organisation.

## A shared interest in CHERI

![Placeholder for CHERI Alliance membership]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

Different perspectives make technical conversations more useful. Application developers, platform engineers, researchers and people responsible for products often approach the same problem with different questions. Bringing those questions together helps a group identify shared priorities and describe the work in terms that others can follow.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

Progress can take several forms: an improved explanation, a reproducible experiment, a useful review or a clearer understanding of a limitation. Sharing the reasoning behind a decision makes that progress easier to build on. The most helpful next contribution is often a small one that another person can use.

## Find your contribution

![Placeholder for community contributions]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

A route into CHERI can begin with the concepts, a practical example or a conversation with the community. Different readers need different levels of detail. A clear overview should establish the subject, explain the terminology and offer a useful next step without assuming that everyone has the same background.

Keep conceptual explanations close to the examples that make them concrete. A diagram, a short exercise and a few carefully chosen questions can make a new topic easier to discuss. Readers should be able to move from the broad idea to a more detailed reference when they are ready.

Learning is easier to continue when each session leaves a useful record. Keep a short glossary, note the references that helped and capture the questions that remain. These small resources support the next conversation and help connect individual learning with shared work across the CHERI ecosystem.

## Start a conversation

![Placeholder for an Alliance membership enquiry]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

An initial membership conversation can begin with the work already under way in an organisation. Technical interests, evaluation questions and the experience a team hopes to share all help establish a useful starting point. A short introduction is enough to identify the next conversation.

Consider who would take part and what they would like to learn. Some people may focus on software, while others are interested in platforms, tools, education or the wider adoption of memory-safety approaches. Naming those interests helps connect the enquiry to relevant subjects.

Membership terms, eligibility and commitments should be confirmed through the Alliance's published information and a direct conversation. The sample material here does not set membership conditions or promise benefits. [Contact the Alliance]({{ '/contact/' | relative_url }}) to continue.
