# Current implementation brief

Preserve the attached Jekyll site's design and content while refining authoring
and interaction. Return the complete source as a ZIP.

- Keep Jekyll, Kramdown, Liquid, SCSS, vanilla JavaScript and GitHub Pages support.
- Preserve the logo assets, typography, flat layout and home-only dark theme; align both palettes with CHERI Alliance colours and maintain readable contrast.
- Remove sample flags and the page-level content notice.
- Make rendered Markdown tables horizontally scrollable on narrow screens.
- Supply one page of copyable examples and rendered output: headings, images
  aligned left/right/full width, tables, heroes, carousels, onward links and forms.
- Group related front-matter properties, particularly images. Prefer hyphenated
  compound keys; retain underscores required by Jekyll or its redirect plugin.
- Make each carousel slide's full surface follow its CTA, while its navigation
  controls continue to operate the carousel.
- Remove descriptive text from Where next.
- Support redirects and explicit external links that open in a new tab.
- Keep internal URLs compatible with both root and repository-prefix deployments.
- Keep native links and content usable without JavaScript.
- Keep forms non-submitting until an endpoint is supplied.

The implemented authoring contract is in `markup-examples.md`. News stays newest
first; events stay earliest first. Member and speaker cards retain image and
title only. Verification and its limitations are recorded in `VERIFICATION.md`.

Current refinements also require minimal, grouped front matter, one visible
introduction sourced from the opening Markdown paragraph,
nested listing controls, 16:9 news/event thumbnails, square speakers, a viewport-sized
image dialog, accurate placeholder labels, `target`/`rel` link attributes,
optional news author/company and a central `_redirects` collection with collision
and loop validation.

Placeholder labels show aspect ratios. The demo news authors are Dan Sullivan,
Adam Finney and Mike Eftimakis. Ordinary text links turn red on hover while
navigation and cards retain their existing interaction styling. Section
backgrounds are configurable RGBA colours over a subtle body watermark that
matches the logo’s rounded hexagon, without modifying either logo master.

The body uses a composed hexagon/honeycomb background with staggered cells,
diagonal tonal ribbons and larger anchor cells. Every cell is a hollow outline
formed from 1px horizontal lines with 1px gaps, with a transparent centre.
Bake the 1px lines and transparent 1px gaps into the WebP files and display
them at native size to retain that spacing in CSS pixels. Keep all
cells separate, including at repeating tile boundaries. The tile must repeat
seamlessly on both axes: edge-crossing cells wrap onto the opposite edge,
and its even height preserves the alternating pixel rows. Grain is removed.
Make the pattern visible through slightly more translucent page sections
while keeping text readable.

Cards must have clear boundaries in normal and hover states in both themes.
Use stronger translucent tints without decorative borders or shadows, plus distinct blue hero fills.
The Subscribe card must stand out against its dark band with readable text
and focus states. Speaker detail portraits reuse the listing thumbnail in
a square frame. Form introductions and instructions belong in Markdown,
without a separate `intro` property.

Components are one include level deep. Keep named page components, but inline
smaller byline, date, image, URL and link-attribute helpers. The header must
preserve its navigation hierarchy without nested includes.

Keep the SVG background source and serve lossless WebP backgrounds in both
themes without a live SVG mask or CSS striping overlay. Retain 1px horizontal
lines and 1px transparent gaps in the actual WebP pixels.
Include an ICO favicon based on the official icon from cheri-alliance.org.

Use the named list/detail layouts `people`/`person`, `events`/`event`,
`news`/`post` and `members`/`member`. Inherit collection layouts, parents and
shared onward links through defaults. Preserve the page hierarchy and all
existing URLs. Keep description/summary overrides optional, infer internal
onward-link titles, and remove redundant author-supplied image attributes.

Use `_people/` and `site.people` internally. Public directory titles and URLs
remain independent: the sample Speakers directory and its `/speakers/`
profile URLs are retained. Dark mode uses a darker, more opaque content
background to subdue the watermark beneath text. The dark hero keeps its
original colour at a subtly reduced 60% opacity. Keep the original card and
onward-link fill settings, including hover/focus states. Shared colour values
remain in `_sass/settings.scss`.
