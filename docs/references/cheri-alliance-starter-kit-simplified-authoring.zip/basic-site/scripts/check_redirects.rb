# Run before building: bundle exec ruby scripts/check_redirects.rb [/baseurl]
require 'jekyll'
require 'uri'

module RedirectChecks
  module_function

  # Directory URLs and explicit index.html URLs occupy the same output file.
  def route(path)
    decoded = URI::DEFAULT_PARSER.unescape(path)
    decoded += 'index.html' if decoded.end_with?('/')
    decoded
  end

  def errors(site)
    errors = []
    pages = site.pages.select { |page| page.output_ext == '.html' }
    pages += site.collections.values.select(&:write?).flat_map(&:docs)
    files = {}
    redirects = {}
    baseurl = site.baseurl.to_s.sub(%r{/$}, '')
    origin = URI.parse(site.config['url'].to_s)

    pages.each do |page|
      key = route(page.url)
      if files.key?(key)
        errors << "Duplicate output path #{page.url}: #{files[key]} and #{page.path}"
      else
        files[key] = page.path
      end
      if page.respond_to?(:collection) && page.collection.label == 'redirects'
        errors << "#{page.path}: provide permalink and redirect_to" unless page.data['permalink'] && page.data['redirect_to']
        errors << "#{page.path}: redirects must not have a parent" if page.data['parent']
      end
    end
    site.static_files.each do |file|
      key = route(file.relative_path)
      errors << "Output path conflicts with a static file: #{key}" if files.key?(key)
      files[key] ||= file.relative_path
    end

    add_redirect = lambda do |source, target, owner|
      begin
        source_uri = URI.parse(source.to_s)
        source_path = URI::DEFAULT_PARSER.unescape(source_uri.path.to_s)
        valid_source = source_path.start_with?('/') && !source_uri.host && !source_uri.scheme && !source_uri.query && !source_uri.fragment
        valid_source &&= source_path.end_with?('/', '.html') && (source_path.split('/') & ['.', '..']).empty?
        unless valid_source
          errors << "#{owner}: redirect source must be a root-relative directory URL or .html path: #{source}"
          next
        end
        key = route(source_path)
        if redirects.key?(key)
          errors << "#{owner}: duplicate redirect source #{source}"
          next
        end
        unless target.is_a?(String) && !target.strip.empty?
          errors << "#{owner}: redirect destination must be one non-empty URL"
          next
        end
        uri = URI.parse(target)
        local_path = nil
        if uri.scheme || uri.host
          unless %w[http https].include?(uri.scheme) && uri.host
            errors << "#{owner}: external destinations must use http:// or https://"
            next
          end
          if origin.host && uri.host == origin.host && uri.scheme == origin.scheme && uri.port == origin.port
            path = uri.path.empty? ? '/' : uri.path
            if baseurl.empty?
              local_path = path
            elsif path == baseurl || path.start_with?(baseurl + '/')
              local_path = path.delete_prefix(baseurl)
              local_path = '/' if local_path.empty?
            end
          end
        elsif uri.path.start_with?('/')
          local_path = uri.path
          if !baseurl.empty? && (local_path == baseurl || local_path.start_with?(baseurl + '/'))
            errors << "#{owner}: omit baseurl from the internal destination: #{target}"
          end
        else
          errors << "#{owner}: internal destinations must start with /"
          next
        end
        redirects[key] = local_path ? route(local_path) : nil
      rescue URI::InvalidURIError
        errors << "#{owner}: invalid redirect URL"
      end
    end

    pages.each do |page|
      target = page.data['redirect_to']
      add_redirect.call(page.url, target, page.path) if target
      Array(page.data['redirect_from']).each do |source|
        if files.key?(route(source.to_s))
          errors << "#{page.path}: redirect alias conflicts with an existing page or file: #{source}"
        end
        add_redirect.call(source, target || page.url, page.path)
      end
    end

    redirects.each do |source, target|
      if target && !files.key?(target) && !redirects.key?(target)
        errors << "#{source}: internal redirect destination does not exist: #{target}"
      end
      visited = []
      current = source
      while current && redirects.key?(current)
        if visited.include?(current)
          errors << "Redirect loop: #{(visited + [current]).join(' -> ')}"
          break
        end
        visited << current
        current = redirects[current]
      end
    end
    errors.uniq
  end
end

if $PROGRAM_NAME == __FILE__
  options = { 'source' => File.expand_path('..', __dir__), 'quiet' => true }
  options['baseurl'] = ARGV[0] if ARGV[0]
  site = Jekyll::Site.new(Jekyll.configuration(options))
  site.reset
  site.read
  errors = RedirectChecks.errors(site)
  abort errors.join("\n") unless errors.empty?
  puts 'PASS: redirect sources, destinations, output conflicts and loops.'
end
