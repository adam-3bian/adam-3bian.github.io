# Run after a build: bundle exec ruby scripts/check_site.rb _site [/baseurl]
# Uses Jekyll and Nokogiri already supplied by the retained github-pages bundle.
require 'jekyll'
require 'nokogiri'
require 'uri'
require_relative 'check_redirects'

source = File.expand_path('..', __dir__)
destination = File.expand_path(ARGV[0] || '_site', source)
abort "Build directory not found: #{destination}" unless Dir.exist?(destination)
options = { 'source' => source, 'destination' => destination, 'quiet' => true }
options['baseurl'] = ARGV[1] if ARGV[1]
site = Jekyll::Site.new(Jekyll.configuration(options))
site.reset
site.read
baseurl = site.baseurl.to_s.sub(%r{/$}, '')
pages = site.pages.select { |page| page.output_ext == '.html' }
pages += site.collections.values.select(&:write?).flat_map(&:docs)
by_url = pages.to_h { |page| [page.url, page] }
errors = RedirectChecks.errors(site)
Dir.glob(File.join(source, '_includes', '**', '*.html')).each do |file|
  if File.read(file).match?(/{%-?\s*include(?:_relative)?\s/)
    errors << "#{File.basename(file)}: components must not include other files."
  end
end
errors << 'Two source pages have the same URL.' unless by_url.size == pages.size
documents = Dir.glob(File.join(destination, '**', '*.html')).to_h do |file|
  [file, Nokogiri::HTML(File.read(file))]
end
errors << 'No generated HTML pages found.' if documents.empty?
link_count = 0

def refresh_target(document)
  meta = document.css('meta').find { |node| node['http-equiv'].to_s.downcase == 'refresh' }
  meta && meta['content'].to_s.split(/url\s*=\s*/i, 2)[1]&.strip
end

def output_file(destination, url)
  path = url.sub(%r{^/}, '')
  path += 'index.html' if path.end_with?('/') || path.empty?
  File.join(destination, path)
end

def redirect_url(site, baseurl, target)
  return target if target.match?(%r{\A(?:https?:)?//})
  "#{site.config['url']}#{baseurl}#{target}"
end

# Check actual destinations for alias and redirect-only pages. The redirect
# plugin's generated pages intentionally do not have the regular site shell.
pages.each do |page|
  target = page.data['redirect_to']
  target = target.first if target.is_a?(Array)
  expected_target = redirect_url(site, baseurl, target || page.url)
  aliases = Array(page.data['redirect_from'])
  aliases.each do |old_url|
    errors << "#{page.url}: redirect alias conflicts with a page: #{old_url}" if by_url.key?(old_url)
  end
  paths = aliases + (target ? [page.url] : [])
  paths.each do |path|
    file = output_file(destination, path)
    document = documents[file]
    errors << "#{path}: redirect page missing or target incorrect" unless document && refresh_target(document) == expected_target
  end
end

pages.each do |page|
  next if page.data['redirect_to']
  trail = []
  visited = [page.url]
  parent = page.data['parent']
  while parent && parent != ''
    if visited.include?(parent)
      errors << "#{page.url}: cyclic parent relationship at #{parent}"
      break
    end
    ancestor = by_url[parent]
    unless ancestor
      errors << "#{page.url}: missing parent #{parent}"
      break
    end
    visited << parent
    trail.unshift(ancestor)
    parent = ancestor.data['parent']
  end
  errors << "#{page.url}: more than 12 ancestors" if trail.size > 12
  path = page.url.sub(%r{^/}, '')
  path += 'index.html' if path.end_with?('/') || path.empty?
  document = documents[File.join(destination, path)]
  unless document
    errors << "#{page.url}: generated page is missing"
    next
  end
  crumbs = document.css('.breadcrumbs a').map { |a| a['href'] }
  expected = trail.map { |ancestor| baseurl + ancestor.url }
  errors << "#{page.url}: breadcrumb trail does not match parents" unless crumbs == expected
  if page.data['parent']
    current = document.at_css('.breadcrumbs [aria-current="page"]')
    title = page.data['nav-title'] || page.data['title']
    errors << "#{page.url}: current breadcrumb missing or incorrect" unless current && current.text == title
  end
  if page.data['layout'] == 'index'
    children = pages.select { |child| !child.data['redirect_to'] && child.data['parent'] == page.url }.sort_by { |child| child.data['title'].downcase }
    actual = document.css('.index-list .card').map { |card| card['href'] }
    errors << "#{page.url}: child index does not match parents" unless actual == children.map { |child| baseurl + child.url }
  end
  expected_theme = page.url == '/' ? 'dark' : 'light'
  errors << "#{page.url}: theme violates home-only dark rule" unless document.at_css('body')['data-theme'] == expected_theme
  subscription = site.config['subscribe'] || {}
  subscribe_enabled = subscription['enabled'] && page.data['subscribe'] != false
  calls_to_action = document.css('.site-call-to-action')
  expected_count = subscribe_enabled ? 1 : 0
  errors << "#{page.url}: Subscribe visibility does not match configuration" unless calls_to_action.size == expected_count
  %w[where-next related-pages].each do |key|
    configured = page.data[key]
    enabled = key == 'where-next' ? configured.is_a?(Hash) && configured['url'] : configured.is_a?(Array) && !configured.empty?
    expected = enabled ? 1 : 0
    actual = document.css("section[aria-labelledby='#{key}']").size
    errors << "#{page.url}: #{key} visibility does not match configuration" unless actual == expected
  end
  calls_to_action.each do |call_to_action|
    placed_before_footer = call_to_action.previous_element&.name == 'main' && call_to_action.next_element&.name == 'footer'
    errors << "#{page.url}: Subscribe must sit between main and footer" unless placed_before_footer
    errors << "#{page.url}: Subscribe must contain one linked card" unless call_to_action.css('a.card[href]').size == 1
  end
end

documents.each do |file, document|
  label = file.delete_prefix(destination)
  is_redirect = !refresh_target(document).nil?
  unless is_redirect
    errors << "#{label}: expected one H1" unless document.css('h1').size == 1
    errors << "#{label}: main landmark missing" unless document.at_css('main#main-content')
  end
  ids = document.css('[id]').map { |node| node['id'] }
  errors << "#{label}: duplicate IDs" unless ids.uniq == ids
  document.css('[aria-controls], [aria-labelledby], [aria-describedby]').each do |node|
    %w[aria-controls aria-labelledby aria-describedby].each do |attribute|
      node[attribute].to_s.split.each do |id|
        errors << "#{label}: #{attribute} target #{id} missing" unless ids.include?(id)
      end
    end
  end
  document.css('label[for]').each do |node|
    errors << "#{label}: label target missing" unless ids.include?(node['for'])
  end
  document.css('img').each do |image|
    errors << "#{label}: image alternative text missing" if image['alt'].to_s.strip.empty?
  end
  document.css('section[aria-labelledby="where-next"] p').each do
    errors << "#{label}: Where next must not contain a description"
  end
  document.css('a.card:not(.slide-link) p').each { errors << "#{label}: description paragraph inside listing/onward card" }
  document.css('.slide').each do |slide|
    link = slide.at_css('a.slide-link')
    next unless link
    valid = slide.css('a').size == 1 && link.parent == slide && link.at_css('img') && link.at_css('.slide-copy .card-action')
    errors << "#{label}: slide must be one full CTA link" unless valid
    errors << "#{label}: carousel must not use image overlay" if slide.at_css('[data-image-overlay]')
  end
  document.css('.slider').each do |slider|
    errors << "#{label}: carousel must be a separate main section outside the hero" unless slider.parent.name == 'main'
    removed = slider.css('[data-slider-previous], [data-slider-next], [data-slider-play], .slider-status')
    errors << "#{label}: carousel contains removed controls or status text" unless removed.empty?
    selectors = slider.css('.slider-controls button')
    valid = selectors.size == slider.css('.slide').size && selectors.all? do |button|
      button['data-slide'] && button['aria-label'].to_s.start_with?('Slide ') && button.text.strip == '●'
    end
    errors << "#{label}: carousel controls must be labelled Unicode dot buttons" unless valid
  end
  document.css('a[target="_blank"], a[data-external="true"], a.external').each do |link|
    valid = link['target'] == '_blank' && %w[noopener noreferrer].all? { |rel| link['rel'].to_s.split.include?(rel) }
    errors << "#{label}: external link needs a new-tab target and safe rel attributes" unless valid
  end
  document.css('[style]').each do |node|
    # Kramdown emits alignment styles for Markdown table columns.
    table_alignment = %w[th td].include?(node.name) && node['style'].match?(%r{\Atext-align:\s*(left|center|right);?\z})
    errors << "#{label}: unexpected inline styles present" unless table_alignment
  end
  document.css('[href], [src]').each do |node|
    value = node['href'] || node['src']
    begin
      uri = URI.parse(value)
      next if uri.scheme || uri.host
      path = URI::DEFAULT_PARSER.unescape(uri.path.to_s)
      if path.empty?
        target = file
      else
        unless path.start_with?('/') && (baseurl.empty? || path == baseurl || path.start_with?(baseurl + '/'))
          errors << "#{label}: internal URL missing baseurl: #{value}"
          next
        end
        path = path.delete_prefix(baseurl).sub(%r{^/}, '')
        path += 'index.html' if path.end_with?('/') || path.empty?
        target = File.expand_path(path, destination)
      end
      unless target.start_with?(destination + '/') && File.file?(target)
        errors << "#{label}: missing local resource #{value}"
        next
      end
      if uri.fragment && documents[target]
        fragment = URI::DEFAULT_PARSER.unescape(uri.fragment)
        errors << "#{label}: missing fragment #{value}" unless documents[target].css('[id]').any? { |element| element['id'] == fragment }
      end
      link_count += 1
    rescue URI::InvalidURIError
      errors << "#{label}: invalid URL #{value}"
    end
  end
end

%w[news events].each do |name|
  document = documents[File.join(destination, name, 'index.html')]
  next unless document
  dates = document.css('article.content > .cards > li > .card').map do |card|
    time = card.at_css('time')
    errors << "#{name}: title must appear before date" unless time && time.parent.previous_element&.name == 'h2'
    time && time['datetime']
  end.compact
  expected_dates = name == 'news' ? dates.sort.reverse : dates.sort
  direction = name == 'news' ? 'latest to earliest' : 'earliest to latest'
  errors << "#{name}: dates are not #{direction}" unless dates == expected_dates
end
pages.select { |page| %w[members people].include?(page.data['layout']) }.each do |page|
  name = page.url
  document = documents[output_file(destination, name)]
  next unless document
  cards = document.css('article.content > .cards > li > .card')
  titles = cards.map { |card| card.at_css('h2')&.text.to_s }
  errors << "#{name}: titles are not alphabetical" unless titles == titles.sort_by(&:downcase)
  cards.each do |card|
    children = card.element_children
    valid = children.size == 2 && children[0]['class'] == 'card-media' && children[0].css('img').size == 1 && children[1].name == 'h2'
    errors << "#{name}: directory card must contain only image and title" unless valid
  end
end
abort errors.uniq.join("\n") unless errors.empty?
puts "PASS: #{documents.size} pages, #{link_count} local links/assets, parent chains, indexes, headings, ARIA references, cards, carousel links, external links, redirects, ordering, Subscribe visibility and themes (baseurl #{baseurl.empty? ? '/' : baseurl})."
puts 'Static checks only; complete the browser checklist in VERIFICATION.md.'
