// Optional asset-authoring step: npm install --no-save sharp
// Run with: node scripts/render_backgrounds.cjs
// Jekyll uses the committed WebP files and does not need Node or Sharp.
const fs = require('node:fs');
const path = require('node:path');
const sharp = require('sharp');

const root = path.resolve(__dirname, '..');
const settings = fs.readFileSync(path.join(root, '_sass/settings.scss'), 'utf8');
const light = settings.match(/^\$colour-watermark:\s*rgba\(#([a-f\d]{6}),/im);
const dark = settings.split('$theme-dark:')[1]?.match(/\bwatermark:\s*rgba\(#([a-f\d]{6}),/i);
if (!light || !dark) throw new Error('Use rgba(#rrggbb, opacity) for both watermark settings.');

(async () => {
  const source = path.join(root, 'assets/images/background/hexagons.svg');
  // Render at native size: one image pixel maps to one CSS pixel.
  const {data, info} = await sharp(source, {density: 72})
    .ensureAlpha().raw().toBuffer({resolveWithObject: true});
  // A repeated tile must keep the same on/off row phase at each vertical join.
  if (info.height % 2 !== 0) throw new Error('The background tile height must be even for 1px lines/gaps.');
  for (const [theme, match] of [['light', light], ['dark', dark]]) {
    const rgb = [0, 2, 4].map(index => parseInt(match[1].slice(index, index + 2), 16));
    const pixels = Buffer.from(data);
    for (let offset = 0; offset < pixels.length; offset += 4) {
      for (let channel = 0; channel < 3; channel++) pixels[offset + channel] = rgb[channel];
      // Bake a 1px horizontal line / 1px transparent gap into the image.
      const row = Math.floor(offset / (info.width * 4));
      if (row % 2 === 1) pixels[offset + 3] = 0;
    }
    const destination = path.join(root, `assets/images/background/hexagons-${theme}.webp`);
    await sharp(pixels, {raw: {width: info.width, height: info.height, channels: 4}})
      .webp({lossless: true, effort: 6}).toFile(destination);
    console.log(`${path.relative(root, destination)}: ${info.width} × ${info.height}`);
  }
})().catch(error => { console.error(error.message); process.exitCode = 1; });
