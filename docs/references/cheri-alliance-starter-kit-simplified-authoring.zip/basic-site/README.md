# CHERI Alliance website kit

A Jekyll starter with semantic HTML, Kramdown, Liquid, SCSS and vanilla
JavaScript. The existing layouts, Poppins typography, official logos and sample
page prose are retained. Home remains the only dark page. The two themes now
use the Alliance’s blue, beige, white and charcoal palette, with contrasting
shades for interactive states and dark backgrounds.

## Start here

The single **[markup examples page](markup-examples.md)** renders at
`/markup-examples/`. It contains copyable front matter, headings, left/right/full
images, a scrolling table, heroes, carousels, forms, links, optional news
attribution and redirects. `/examples/` still redirects to it.

## Run locally

With Ruby and Bundler installed, enter `basic-site/`:

```sh
bundle install
bundle exec ruby scripts/check_redirects.rb
bundle exec jekyll serve
```

The retained `github-pages` bundle uses version 232 and Jekyll 3.10.
`jekyll-redirect-from` is enabled. No custom Jekyll plugin, Node build step or
icon framework is required. Poppins uses the existing Google Fonts stylesheet
and falls back to Arial/sans-serif.

## Build and check

Validate redirect source files **before** building, so collisions are reported
before two pages can write to the same output path:

```sh
bundle exec ruby scripts/check_redirects.rb
bundle exec jekyll build --destination _site
bundle exec ruby scripts/check_site.rb _site

bundle exec ruby scripts/check_redirects.rb /cheri-preview
bundle exec jekyll build --baseurl /cheri-preview --destination _site
bundle exec ruby scripts/check_site.rb _site /cheri-preview
```

Use the same baseurl for a build and its checker. `VERIFICATION.md` records the
checks completed for this delivery and any remaining limitations.

For GitHub Pages, put `basic-site/` contents at the repository root. Set `url`
to the public origin, and `baseurl` to `''` for a root deployment or
`/REPOSITORY-NAME` for a project site. Keep source paths rooted at `/` without
that prefix; templates and the redirect plugin add it when rendering.

## Where to edit

| Location | Purpose |
| --- | --- |
| Root `.md` files | Pages, indexes, forms and the single examples page |
| `_posts/` | News; optional `author` and `company` |
| `_events/`, `_members/`, `_people/` | Collection detail pages |
| `_redirects/` | One source path and destination per Markdown file |
| `_data/navigation.yml` | Header, nested menus, footer and social links |
| `_config.yml` | Collection defaults, deployment and Subscribe |
| `_sass/settings.scss` | Theme colours, type, spacing and image-frame sizes |
| `_includes/`, `_layouts/` | Shared semantic rendering components |
| `assets/js/` | Navigation, carousel, image and table enhancements |

## Front-matter conventions

Write the introduction as the first Markdown paragraph. It appears once below
its heading, in the hero or ordinary page, and supplies search metadata.
Additional Markdown follows in the body; on forms it appears above the fields.
`description` remains an optional metadata override, and older `summary`
values are still supported. Neither field is needed in normal content files.

A standard root page needs only `title`: Markdown pages inherit the `page`
layout and the filename supplies the URL. Keep `permalink` for a different or
nested URL, and `parent` for deeper hierarchy. Collection details inherit their
layout, parent and shared onward links from `_config.yml`.

| Content | List template | Detail template | Ordering |
| --- | --- | --- | --- |
| People | `people` | `person` | Alphabetical |
| Events | `events` | `event` | Earliest first |
| News | `news` | `post` | Latest first |
| Members | `members` | `member` | Alphabetical |

Named list layouts choose their collection, order and card style. Use
`listing.columns` when needed; the generic `list` layout remains available for
custom collection settings. `index` still discovers children from `parent`.

Store person profiles in `_people/`; the collection is available as `site.people`.
The sample directory still uses the public title Speakers and `/speakers/`
URLs. Its source, `speakers.md`, now selects `layout: people`, and profiles
inherit `layout: person`. Titles and public routes are independent of the
internal collection and layout names.

Keep related properties nested beneath `thumbnail`, `hero`, `slider`,
`listing`, `form`, `where-next` and `related-pages`. Internal onward links infer
the destination title. Omit default action labels and unused optional settings.
Use `where-next: false` or `related-pages: []` to hide collection defaults.

Forms default to method post, text inputs, full-width fields, optional values,
six textarea rows and a Send enquiry button. Only specify overrides such as
`size: half`, `type: email` or `required: true`. Missing/empty endpoints keep
the form a non-submitting demo. Keep descriptive copy in Markdown.

News retains independent optional `author` and `company` fields. The byline
appears after the date, without an empty label or dangling separator.

## Images and interaction

| Image | Source dimensions | Display ratio |
| --- | --- | --- |
| Speaker and member thumbnails | 800 × 800 | 1:1 |
| News and event thumbnails | 1600 × 900 | 16:9 |
| Left/right body images | 1200 × 800 | 3:2 |
| Full-width body images | 1600 × 900 | 16:9 |
| Slider images (`slider.svg`) | 1920 × 1080 | 16:9 |
| Footer icons | 24 × 24 | 1:1 |

The placeholder labels show aspect ratios (`1:1`, `3:2` or `16:9`), not pixel sizes.
Their source dimensions and viewBoxes agree with those ratios.
`cover` crops within fixed frames; `contain` shows the entire image. Both
preserve proportions. The official logo masters are unchanged.

Markdown images need only their alignment class. Source `width` and `height`
remain optional for reserving space before loading, particularly for raster
images; the sample markup omits them. The content script adds lazy loading
when no loading attribute is supplied, and respects explicit overrides. Fixed
carousel, thumbnail and social-icon frames already reserve their space.
Body images retain their proportions and expand into the available viewport,
leaving a small outer margin, caption and accessible Close button. Escape closes
the dialog and restores focus.

Carousel image, text, action and padding form one native link. The carousel
remains outside the hero, with 50/50 desktop columns and mobile stacking. Its
only controls are centred Unicode `●` buttons. Home advances every five seconds;
hovering or clicking a dot does not stop autoplay. Playback waits while the
current slide link has keyboard focus or the tab is hidden. Reduced-motion
preferences disable autoplay. The first slide’s link works without JavaScript.

Where next has no description. Markdown tables scroll horizontally on narrow
screens, with keyboard focus added when they overflow and a CSS-only fallback.

## Links and redirects

Use `target` and `rel`, matching Kramdown:

```yaml
url: https://cheri-alliance.org/
target: _blank
rel: noopener noreferrer
```

```markdown
[CHERI Alliance](https://cheri-alliance.org/){: target="_blank" rel="noopener noreferrer"}
```

Templates preserve supplied attributes and add missing safe rel tokens for
`_blank`. Other rel tokens are retained. The content script still opens
unmarked off-site web links in new tabs; explicit `_self` or named targets take
precedence. There is no `external` front-matter flag.

Each `_redirects/*.md` file needs only `permalink` and `redirect_to`. The collection
preserves `/examples/` and includes `/alliance-website/` as an external example.
Redirects are excluded from navigation, listings and the sitemap. The pre-build
checker catches duplicate paths, collisions, missing local destinations and
loops, including retained legacy aliases. These are static HTML refresh pages,
not HTTP 301/302 responses; those status codes need host configuration.

## Forms, footer and Subscribe

Contact, Subscribe and the examples page retain non-submitting demonstration
forms. Connect a real endpoint before expecting delivery.

Edit social destinations in `_data/navigation.yml`. The native LinkedIn,
Mastodon and Slack image links remain below Connect on desktop and above the
copyright on mobile. Slack links to the public CHERI-CPU joining instructions.
Icons are local SVG assets with alternative text, not inline SVG or an icon font.

The Subscribe band remains dark and distinct from light page content, with
its own translucent dark blue background. Content and destination still come
from `subscribe` in `_config.yml`.

## Component structure

Layouts include page-sized components such as `hero.html`, `slider.html`,
`listing.html`, `where-next.html` and `related-pages.html`. Each component is
self-contained: files in `_includes/` never include another file. Dates,
bylines, images and link attributes are written directly where they render.
The header walks the menu tree within `header.html`, preserving nested
navigation without a recursive include or fixed menu-depth limit.

`favicon.ico` is generated from the official favicon published by
cheri-alliance.org. The original PNG is retained under `assets/images/brand/`.
The layout links to the ICO with `relative_url`, including on prefixed sites.

## Theme settings and watermark

Edit `_sass/settings.scss` for both themes. Section backgrounds use
`rgba(colour, alpha)`: the second argument is opacity, where `1` is solid and
`0` is fully transparent. Page, header, hero, cards, onward links and the footer /
Subscribe band have independent values. Only their backgrounds are translucent;
text, menus, form controls and the expanded-image dialog remain opaque.

Cards use richer translucent blue tints in both themes, so they stand out
before hover while the honeycomb remains visible through them. Cards and
heroes have no decorative borders or shadows. The hero uses a translucent
pale blue/light or deeper blue/dark background. Subscribe has independent `subscribe-band`,
`subscribe-card`, `subscribe-card-hover` and `subscribe-text` settings: its
translucent pale blue fill and dark text contrast with the dark band in both
themes. Keyboard focus outlines remain visible.

Dark mode uses a 90%-opaque deep charcoal-blue content background to subdue
the watermark behind body text. The dark hero keeps its original colour
with a subtly lower opacity of 60% (previously 64%). Card and onward-link
fill settings, including hover/focus states, retain their original values.
Adjust `page` and `hero` in `$theme-dark`; the light palette is independent.

Section spacing is shared by both themes: 40px on mobile and 56px on desktop
at the default text size. A leading card list or index uses that section gap
without adding another margin inside it. Dated listing cards keep the date
and action together at the bottom, so different title lengths do not stagger
those details. Cards can still grow for longer titles or wrapping dates.

The `person` detail layout automatically reuses the listing `thumbnail` as
the first body image; no portrait markup is needed in the Markdown source.
The `image-square` class reserves a 1:1 frame, uses the image’s `fit` setting
and works before and after the image-enlargement link is added.

The body uses a composed honeycomb background based on the logo’s rounded
outer hexagon. Staggered cells form soft diagonal tonal ribbons around four
larger anchor cells. Every cell is a hollow outline built from horizontal
1px strokes separated by 1px transparent gaps baked into the WebP pixels;
the centres stay transparent. The strokes are clipped
inside the original contour, and cells remain separated across repeating
tiles. Both logo masters are unchanged. There is no grain layer.

The live background uses `hexagons-light.webp` and `hexagons-dark.webp`,
lossless 1518 × 1926 exports of the retained `hexagons.svg` source. Cells that
cross a tile edge continue on the opposite edge, and the staggered grid and
tonal bands repeat seamlessly in both directions. It uses
ordinary CSS background images, with no SVG loading or CSS mask dependency.
The exporter clears every other pixel row in each WebP. CSS displays the
images at native size, centred and repeating on both axes, so one image pixel
maps to one CSS pixel. Narrow viewports crop the composition rather than
shrinking the lines and gaps together. The even tile height preserves the
1px-on, 1px-off rhythm at every vertical join. No CSS striping layer is needed. The
background is decorative, ignores pointer events and is hidden in print and
forced-colour mode.

`watermark` in each theme uses `rgba(#rrggbb, opacity)`. Its opacity changes
immediately on the next Jekyll build; use `0` to hide it. Changing its RGB
colour or the SVG geometry requires regenerating the WebP assets. From the
site directory, install the optional authoring dependency and run:

```sh
npm install --no-save sharp
node scripts/render_backgrounds.cjs
```

The generated files are included in this ZIP. Normal Jekyll/GitHub Pages
builds need neither Node nor Sharp. Section opacity separately controls how
much of the pattern shows through, without fading text.

Ordinary text links turn red on hover, using `link-hover` in each theme. The
dark theme uses a lighter red for contrast. Navigation links, cards, logos,
buttons and image-enlargement links keep their existing hover behaviour.
