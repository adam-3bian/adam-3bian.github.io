## CHERI illustration with left alignment

![Landscape placeholder for a CHERI illustration]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

Introduce a CHERI subject in two short paragraphs. This image uses the existing left-alignment class and retains its source proportions.

Continue the explanation alongside the image on wider screens.

## CHERI illustration with right alignment

![Landscape placeholder for a CHERI illustration]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

Introduce a second CHERI subject. Only the alignment class changes; the page uses the same shared Markdown content styles.

The next heading clears this floated image.

## CHERI illustration at full width

![Full-width placeholder for a CHERI illustration]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

Use a full-width image for supporting CHERI material that benefits from the complete content width.
