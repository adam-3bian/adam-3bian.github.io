# Authoring examples

All current authoring examples are on one page: **[markup-examples.md](../markup-examples.md)**.
After building, open `/markup-examples/` (or `/examples/`, its redirect alias).

That page is both a working example and the source to copy from. It covers
headings, left/right/full-width images, scrollable tables, nested front matter,
heroes, clickable carousels, Where next, related pages, forms, hierarchy,
external links and redirects. It replaces the previous separate tutorial.
