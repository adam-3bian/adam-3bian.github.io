---
layout: forms
title: Subscribe for updates
form:
  id: subscription-form
  title: Join the mailing list
  submit: Subscribe
  demo: 'Demonstration subscription form: no mailing-list service is connected. Nothing will be sent.'
  fields:
    - name: email
      size: half
      label: Email address
      type: email
      required: true
      autocomplete: email
      placeholder: you@example.org
    - name: name
      size: half
      label: Your name
      autocomplete: name
      placeholder: Your name (optional)
where-next:
  action: Browse news
  url: /news/
related-pages:
  - url: /events/
  - action: Browse resources
    url: /resources/
  - action: Get in touch
    url: /contact/
subscribe: false
---

Keep in touch with CHERI Alliance news, resources and community events.
