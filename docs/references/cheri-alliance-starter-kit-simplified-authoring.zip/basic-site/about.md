---
title: About the CHERI Alliance
where-next:
  url: /membership/
related-pages:
  - url: /members/
  - url: /working-groups/
  - url: /events/
---

A shared focus on CHERI, practical collaboration and stronger software-security foundations.

## A shared purpose

![Placeholder for the Alliance mission]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

Memory safety concerns how software accesses and manages memory throughout its execution. For people exploring CHERI, it provides a useful starting point for discussions about program behaviour, trust and the boundaries between components. The subject connects low-level implementation choices with the wider task of building dependable systems.

A clear discussion separates the problem being considered from the mechanism being evaluated. What access should a component have? Where should that access stop? Which assumptions are enforced, and which still depend on the surrounding software? These questions help keep a technical explanation specific and understandable.

Different applications bring different constraints. Existing code, development tools, deployment environments and the needs of the people maintaining a system all influence the next step. Exploring those constraints alongside the technical concepts gives a more useful starting point than treating one example as a complete answer.

## Working together

![Placeholder for Alliance collaboration]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

Different perspectives make technical conversations more useful. Application developers, platform engineers, researchers and people responsible for products often approach the same problem with different questions. Bringing those questions together helps a group identify shared priorities and describe the work in terms that others can follow.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

Progress can take several forms: an improved explanation, a reproducible experiment, a useful review or a clearer understanding of a limitation. Sharing the reasoning behind a decision makes that progress easier to build on. The most helpful next contribution is often a small one that another person can use.

## Take the next step

![Placeholder for community participation]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A route into CHERI can begin with the concepts, a practical example or a conversation with the community. Different readers need different levels of detail. A clear overview should establish the subject, explain the terminology and offer a useful next step without assuming that everyone has the same background.

Keep conceptual explanations close to the examples that make them concrete. A diagram, a short exercise and a few carefully chosen questions can make a new topic easier to discuss. Readers should be able to move from the broad idea to a more detailed reference when they are ready.

[Explore membership]({{ '/membership/' | relative_url }}) and [find a working group]({{ '/working-groups/' | relative_url }}).
