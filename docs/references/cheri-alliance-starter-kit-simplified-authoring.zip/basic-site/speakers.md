---
layout: people
title: Speakers
where-next:
  url: /contact/
related-pages:
  - title: About the Alliance
    url: /about/
  - url: /membership/
  - url: /working-groups/
---

Sample speaker profiles covering memory safety, software and platform evaluation.
