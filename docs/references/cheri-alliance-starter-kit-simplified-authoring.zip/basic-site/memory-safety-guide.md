---
title: Memory-safety foundations
permalink: /resources/guides/memory-safety/
parent: /resources/guides/
where-next:
  action: Start exploring
  url: /build/
related-pages:
  - action: Browse resources
    url: /resources/
  - action: Explore groups
    url: /working-groups/
  - action: Get in touch
    url: /contact/
---

Start with the questions that connect memory access, software behaviour and trust.

## Start with a clear question

![Placeholder for memory-safety foundations]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

Memory safety concerns how software accesses and manages memory throughout its execution. For people exploring CHERI, it provides a useful starting point for discussions about program behaviour, trust and the boundaries between components. The subject connects low-level implementation choices with the wider task of building dependable systems.

A clear discussion separates the problem being considered from the mechanism being evaluated. What access should a component have? Where should that access stop? Which assumptions are enforced, and which still depend on the surrounding software? These questions help keep a technical explanation specific and understandable.

Different applications bring different constraints. Existing code, development tools, deployment environments and the needs of the people maintaining a system all influence the next step. Exploring those constraints alongside the technical concepts gives a more useful starting point than treating one example as a complete answer.

## Build a useful record

![Placeholder for CHERI learning and evaluation]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

Learning is easier to continue when each session leaves a useful record. Keep a short glossary, note the references that helped and capture the questions that remain. These small resources support the next conversation and help connect individual learning with shared work across the CHERI ecosystem.

## Take the next step

![Placeholder for the next CHERI learning step]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

[Return to the section index]({{ '/resources/guides/' | relative_url }}) or [contact the Alliance]({{ '/contact/' | relative_url }}).
