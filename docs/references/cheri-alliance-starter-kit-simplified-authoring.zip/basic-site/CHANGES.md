# Changes in this revision

- Renamed the internal profiles collection to `people` (`_people/` and
  `site.people`), with `people` for the list layout and `person` for details.
- Updated collection defaults, the sample directory and authoring examples.
  Existing Speakers labels, public URLs and alphabetical ordering are retained.
- Darkened the dark-mode content background and increased its opacity from
  40% to 90%, so the pattern is quieter behind body text.
- Kept the original dark hero colour, reducing its opacity subtly from
  64% to 60%. Card and onward-link fills retain their original values,
  including hover/focus states. Colour settings remain centralised in
  `_sass/settings.scss`.
- Updated directory validation to recognise the `people` and `members`
  layouts independently of their public URLs.

## Previous revision: simplified authoring

- Added the named list/detail layouts: `speakers`/`speaker`, `events`/`event`,
  `news`/`post` and `members`/`member`. Their collection, order and card style
  are selected by the list layout; collection details inherit their layout.
- Moved introductory copy from repeated description/summary fields into the
  opening Markdown paragraph. It appears once below the page heading and
  supplies metadata. Optional metadata and legacy summary overrides still work.
- Moved shared collection parents and onward links into `_config.yml` defaults.
  Internal onward cards infer destination titles, with custom labels supported.
- Removed repeated default page layouts, filename-derived permalinks, default
  form settings, default action labels and the default carousel interval.
  Nested hierarchy, custom routes and all existing page URLs are preserved.
- Simplified Markdown images to their alignment class. Width/height remain
  optional for reserving image space; lazy loading is added by the content
  script unless the author supplies an explicit loading attribute.
- The speaker detail layout renders its shared square portrait, removing copied
  Liquid/HTML from each speaker's Markdown.
- Updated the single authoring guide with minimal pages, forms, list/detail
  examples, defaults and the remaining optional overrides.

The light/dark styles, seamless striped WebP background, original SVG/logo
assets, favicon, navigation, image enlargement, carousel, redirects and
one-level component structure are preserved.
