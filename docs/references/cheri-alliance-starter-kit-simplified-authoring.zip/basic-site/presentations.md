---
title: Presentations and further reading
permalink: /resources/presentations/
parent: /resources/
where-next:
  action: Start exploring
  url: /build/
related-pages:
  - action: Browse resources
    url: /resources/
  - action: Explore groups
    url: /working-groups/
  - action: Get in touch
    url: /contact/
---

Use different explanations to connect CHERI concepts with practical questions.

## Start with a clear question

![Placeholder for presentations and further reading]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

Consider the purpose of each resource before following a long sequence of links. An overview may establish vocabulary, while a guide may focus on a particular task. Presentations can provide another explanation of the same subject and introduce questions worth returning to during an evaluation.

Bring notes from practical work back to the reading. An unfamiliar term, a surprising result or an incomplete instruction can suggest the next reference to consult. Keeping those questions alongside the source material makes the collection more useful for both individual learning and group discussion.

## Build a useful record

![Placeholder for CHERI learning and evaluation]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

Learning is easier to continue when each session leaves a useful record. Keep a short glossary, note the references that helped and capture the questions that remain. These small resources support the next conversation and help connect individual learning with shared work across the CHERI ecosystem.

## Take the next step

![Placeholder for the next CHERI learning step]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

[Return to the section index]({{ '/resources/' | relative_url }}) or [contact the Alliance]({{ '/contact/' | relative_url }}).
