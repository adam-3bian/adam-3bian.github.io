---
title: Planning a CHERI evaluation
permalink: /resources/guides/evaluation/
parent: /resources/guides/
where-next:
  action: Start exploring
  url: /build/
related-pages:
  - action: Browse resources
    url: /resources/
  - action: Explore groups
    url: /working-groups/
  - action: Get in touch
    url: /contact/
---

Turn a broad interest in CHERI into a small, repeatable investigation.

## Start with a clear question

![Placeholder for planning a cheri evaluation]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

A useful CHERI evaluation begins with a clear question. A small application, a familiar library or a well-understood component gives a team something concrete to investigate. The aim is to understand the work involved, gather useful observations and decide which questions deserve a closer look.

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

Make room for both successful results and open questions. Notes about build steps, dependencies, tests and debugging can be as useful as a final demonstration. A focused next step gives the evaluation a clear conclusion and a practical route back into the wider CHERI community.

## Build a useful record

![Placeholder for CHERI learning and evaluation]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

Learning is easier to continue when each session leaves a useful record. Keep a short glossary, note the references that helped and capture the questions that remain. These small resources support the next conversation and help connect individual learning with shared work across the CHERI ecosystem.

## Take the next step

![Placeholder for the next CHERI learning step]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

[Return to the section index]({{ '/resources/guides/' | relative_url }}) or [contact the Alliance]({{ '/contact/' | relative_url }}).
