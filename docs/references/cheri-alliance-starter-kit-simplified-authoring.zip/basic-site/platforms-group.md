---
title: Sample platform working group
permalink: /working-groups/technical/platforms/
parent: /working-groups/technical/
where-next:
  action: Start exploring
  url: /build/
related-pages:
  - action: Browse resources
    url: /resources/
  - action: Explore groups
    url: /working-groups/
  - action: Get in touch
    url: /contact/
---

A fictional working-group example focused on platforms, tools and useful evaluation questions.

## Start with a clear question

![Placeholder for sample platform working group]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

A route into CHERI can begin with the concepts, a practical example or a conversation with the community. Different readers need different levels of detail. A clear overview should establish the subject, explain the terminology and offer a useful next step without assuming that everyone has the same background.

Keep conceptual explanations close to the examples that make them concrete. A diagram, a short exercise and a few carefully chosen questions can make a new topic easier to discuss. Readers should be able to move from the broad idea to a more detailed reference when they are ready.

Learning is easier to continue when each session leaves a useful record. Keep a short glossary, note the references that helped and capture the questions that remain. These small resources support the next conversation and help connect individual learning with shared work across the CHERI ecosystem.

## Build a useful record

![Placeholder for CHERI learning and evaluation]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

Learning is easier to continue when each session leaves a useful record. Keep a short glossary, note the references that helped and capture the questions that remain. These small resources support the next conversation and help connect individual learning with shared work across the CHERI ecosystem.

## Take the next step

![Placeholder for the next CHERI learning step]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

[Return to the section index]({{ '/working-groups/technical/' | relative_url }}) or [contact the Alliance]({{ '/contact/' | relative_url }}).
