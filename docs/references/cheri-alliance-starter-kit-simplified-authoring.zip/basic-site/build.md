---
title: Build with CHERI
where-next:
  url: /resources/
related-pages:
  - url: /discover/
  - url: /working-groups/
  - url: /contact/
---

Choose a focused question, establish a baseline and plan a first CHERI evaluation.

## Choose a platform

![Placeholder for a CHERI evaluation platform]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

A useful CHERI evaluation begins with a clear question. A small application, a familiar library or a well-understood component gives a team something concrete to investigate. The aim is to understand the work involved, gather useful observations and decide which questions deserve a closer look.

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

Make room for both successful results and open questions. Notes about build steps, dependencies, tests and debugging can be as useful as a final demonstration. A focused next step gives the evaluation a clear conclusion and a practical route back into the wider CHERI community.

## Plan a first evaluation

![Placeholder for a CHERI development workflow]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

A first evaluation works best when its scope is easy to explain. Choose a small task that someone else can repeat and agree on what the observations should help the team understand. The result may be a working example, a list of changes or a clearer set of questions.

1. Select a small application or component.
2. Record the platform and toolchain requirements.
3. Follow the maintained setup instructions for that environment.
4. Run a repeatable set of checks.
5. Record observations and choose the next question.

Keep installation notes, test inputs and the source revision together. If a step behaves differently from expectations, those details give the next discussion a useful starting point. They also make it easier to return to the evaluation after the immediate task is complete.

## Continue with the ecosystem

![Placeholder for CHERI tools and collaboration]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

Different perspectives make technical conversations more useful. Application developers, platform engineers, researchers and people responsible for products often approach the same problem with different questions. Bringing those questions together helps a group identify shared priorities and describe the work in terms that others can follow.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

[Follow the evaluation guide]({{ '/resources/guides/evaluation/' | relative_url }}) or [ask a question]({{ '/contact/' | relative_url }}).
