---
layout: index
title: Guides
permalink: /resources/guides/
parent: /resources/
listing:
  columns: 2
  title: In this section
where-next:
  action: Start exploring
  url: /build/
related-pages:
  - action: Browse resources
    url: /resources/
  - action: Explore groups
    url: /working-groups/
  - action: Get in touch
    url: /contact/
---

A route through memory-safety concepts and a focused CHERI evaluation.

## Find a useful starting point

A route into CHERI can begin with the concepts, a practical example or a conversation with the community. Different readers need different levels of detail. A clear overview should establish the subject, explain the terminology and offer a useful next step without assuming that everyone has the same background.

Keep conceptual explanations close to the examples that make them concrete. A diagram, a short exercise and a few carefully chosen questions can make a new topic easier to discuss. Readers should be able to move from the broad idea to a more detailed reference when they are ready.
