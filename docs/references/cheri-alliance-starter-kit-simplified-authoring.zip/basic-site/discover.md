---
title: Discover CHERI
where-next:
  url: /build/
related-pages:
  - url: /resources/
  - url: /working-groups/
  - title: About the Alliance
    url: /about/
---

Explore memory safety, capabilities and the questions that lead into CHERI.

## Why memory safety matters

![Placeholder for memory-safety foundations]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

Memory safety concerns how software accesses and manages memory throughout its execution. For people exploring CHERI, it provides a useful starting point for discussions about program behaviour, trust and the boundaries between components. The subject connects low-level implementation choices with the wider task of building dependable systems.

A clear discussion separates the problem being considered from the mechanism being evaluated. What access should a component have? Where should that access stop? Which assumptions are enforced, and which still depend on the surrounding software? These questions help keep a technical explanation specific and understandable.

Different applications bring different constraints. Existing code, development tools, deployment environments and the needs of the people maintaining a system all influence the next step. Exploring those constraints alongside the technical concepts gives a more useful starting point than treating one example as a complete answer.

## Hardware-enforced protection

![Placeholder for capability concepts]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

CHERI introduces capabilities as part of the way software can express and enforce access to memory. A useful introduction connects the terminology to questions a developer already recognises: where a reference came from, what it can access and which operations it permits.

Bounds, permissions and the relationships between components provide a vocabulary for discussing these questions. Working through a small example gives each term a concrete role. It also creates a useful opportunity to distinguish a hardware mechanism from the assumptions and choices made by the software around it.

An introductory explanation is a starting point for further reading. Platform documentation and maintained technical references provide the detail needed for a specific evaluation. Keep the questions raised by the example close to those references so the next stage remains focused.

## Explore the technology

![Placeholder for the CHERI learning journey]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A route into CHERI can begin with the concepts, a practical example or a conversation with the community. Different readers need different levels of detail. A clear overview should establish the subject, explain the terminology and offer a useful next step without assuming that everyone has the same background.

Keep conceptual explanations close to the examples that make them concrete. A diagram, a short exercise and a few carefully chosen questions can make a new topic easier to discuss. Readers should be able to move from the broad idea to a more detailed reference when they are ready.

[Read the guides]({{ '/resources/guides/' | relative_url }}) or [plan an evaluation]({{ '/build/' | relative_url }}).
