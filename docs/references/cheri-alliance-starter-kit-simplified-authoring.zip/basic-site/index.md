---
layout: default
title: Home
parent: false
theme: dark
hero:
  size: large
  title: Build with confidence. Powered by CHERI.
slider:
  title: Explore CHERI
  autoplay: true
  slides:
    - title: Discover CHERI
      text: Explore memory safety, capabilities and the foundations for a useful technical conversation.
      image:
        src: /assets/images/placeholders/slider.svg
        alt: CHERI discovery image placeholder
        fit: contain
      action: Discover CHERI
      url: /discover/
    - title: Build with CHERI
      text: Choose a focused evaluation and connect your observations with maintained guidance.
      image:
        src: /assets/images/placeholders/slider.svg
        alt: CHERI evaluation image placeholder
        fit: contain
      action: Start exploring
      url: /build/
    - title: Take part in the community
      text: Find working-group subjects, sample events and routes into an Alliance conversation.
      image:
        src: /assets/images/placeholders/slider.svg
        alt: CHERI community image placeholder
        fit: contain
      action: Explore membership
      url: /membership/
where-next:
  url: /discover/
  image:
    src: /assets/images/placeholders/landscape-left.svg
    alt: CHERI discovery image placeholder
related-pages:
  - url: /build/
  - url: /members/
  - url: /events/
---

Explore memory safety, practical evaluation and the people building the CHERI ecosystem.

## Stronger foundations for software

![Placeholder for CHERI memory-safety concepts]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

Memory safety concerns how software accesses and manages memory throughout its execution. For people exploring CHERI, it provides a useful starting point for discussions about program behaviour, trust and the boundaries between components. The subject connects low-level implementation choices with the wider task of building dependable systems.

A clear discussion separates the problem being considered from the mechanism being evaluated. What access should a component have? Where should that access stop? Which assumptions are enforced, and which still depend on the surrounding software? These questions help keep a technical explanation specific and understandable.

Different applications bring different constraints. Existing code, development tools, deployment environments and the needs of the people maintaining a system all influence the next step. Exploring those constraints alongside the technical concepts gives a more useful starting point than treating one example as a complete answer.

## A route into evaluation

![Placeholder for a first CHERI evaluation]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

A useful CHERI evaluation begins with a clear question. A small application, a familiar library or a well-understood component gives a team something concrete to investigate. The aim is to understand the work involved, gather useful observations and decide which questions deserve a closer look.

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

Make room for both successful results and open questions. Notes about build steps, dependencies, tests and debugging can be as useful as a final demonstration. A focused next step gives the evaluation a clear conclusion and a practical route back into the wider CHERI community.

## An ecosystem built together

![Placeholder for the CHERI community]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

Different perspectives make technical conversations more useful. Application developers, platform engineers, researchers and people responsible for products often approach the same problem with different questions. Bringing those questions together helps a group identify shared priorities and describe the work in terms that others can follow.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

[Discover CHERI]({{ '/discover/' | relative_url }}) or [meet the community]({{ '/events/' | relative_url }}).
