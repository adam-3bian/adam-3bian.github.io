---
layout: events
title: Events
where-next:
  url: /resources/
related-pages:
  - url: /members/
  - url: /speakers/
  - url: /contact/
---

Sample workshops, conferences and introductory sessions for the CHERI community.
