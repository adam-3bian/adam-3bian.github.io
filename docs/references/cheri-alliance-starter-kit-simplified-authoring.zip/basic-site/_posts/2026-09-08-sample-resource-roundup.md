---
title: 'Sample: Resources for getting started'
thumbnail:
  src: /assets/images/placeholders/news-thumbnail.svg
  alt: Landscape placeholder for a CHERI Alliance news image
author: Dan Sullivan
---

A sample reading note connecting CHERI concepts, practical questions and further resources.

## A question worth exploring

![Placeholder for a CHERI sample article]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

Consider the purpose of each resource before following a long sequence of links. An overview may establish vocabulary, while a guide may focus on a particular task. Presentations can provide another explanation of the same subject and introduce questions worth returning to during an evaluation.

Bring notes from practical work back to the reading. An unfamiliar term, a surprising result or an incomplete instruction can suggest the next reference to consult. Keeping those questions alongside the source material makes the collection more useful for both individual learning and group discussion.

## From discussion to practice

![Placeholder for CHERI evaluation notes]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

A route into CHERI can begin with the concepts, a practical example or a conversation with the community. Different readers need different levels of detail. A clear overview should establish the subject, explain the terminology and offer a useful next step without assuming that everyone has the same background.

Keep a record of the starting point: the platform, the tools, the source revision and the behaviour expected from the application. A repeatable baseline makes later discussions easier. It also helps another person follow the same route and distinguish a new observation from a difference in the setup.

Progress can take several forms: an improved explanation, a reproducible experiment, a useful review or a clearer understanding of a limitation. Sharing the reasoning behind a decision makes that progress easier to build on. The most helpful next contribution is often a small one that another person can use.

## Further reading

![Placeholder for CHERI further reading]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A useful resource collection connects introductory material with deeper technical references. Readers should be able to find a starting point, understand the scope of a guide and move towards practical work at a comfortable pace. Clear titles and short introductions help make those choices easier.

[Explore resources]({{ '/resources/' | relative_url }}) and [browse sample events]({{ '/events/' | relative_url }}).
