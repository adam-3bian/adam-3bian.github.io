---
layout: index
title: Working groups
listing:
  columns: 2
  title: Explore working groups
where-next:
  url: /contact/
related-pages:
  - url: /build/
  - url: /resources/
  - url: /membership/
---

Explore focused technical discussions and routes into CHERI collaboration.

## A focus for shared work

![Placeholder for CHERI working-group topics]({{ '/assets/images/placeholders/landscape-left.svg' | relative_url }}){: .image-left}

Different perspectives make technical conversations more useful. Application developers, platform engineers, researchers and people responsible for products often approach the same problem with different questions. Bringing those questions together helps a group identify shared priorities and describe the work in terms that others can follow.

Good collaboration starts with a manageable subject and a clear record of what is being discussed. A short agenda, relevant background material and a summary of open questions give people a way to prepare. They also help someone who joins later understand the context without having to reconstruct every earlier conversation.

Progress can take several forms: an improved explanation, a reproducible experiment, a useful review or a clearer understanding of a limitation. Sharing the reasoning behind a decision makes that progress easier to build on. The most helpful next contribution is often a small one that another person can use.

## Make a useful contribution

![Placeholder for technical collaboration]({{ '/assets/images/placeholders/landscape-right.svg' | relative_url }}){: .image-right}

A useful contribution does not need to begin with a large project. A clear question, a reproducible example or a review of an explanation can give a technical discussion something concrete to work with. The value comes from making the subject easier for the next person to understand.

Before joining a discussion, spend a little time with its background material. Note the scope, the terminology and the open questions. If your experience comes from a different environment, explain that context so others can understand how the observation relates to the work in front of them.

Useful notes make a contribution easier to continue. Describe what was tried, what was expected and what happened. Include enough detail to support a follow-up conversation while keeping the immediate question small and clear.

## Keep the conversation moving

![Placeholder for working-group participation]({{ '/assets/images/placeholders/full-width.svg' | relative_url }}){: .image-full}

A route into CHERI can begin with the concepts, a practical example or a conversation with the community. Different readers need different levels of detail. A clear overview should establish the subject, explain the terminology and offer a useful next step without assuming that everyone has the same background.

Keep conceptual explanations close to the examples that make them concrete. A diagram, a short exercise and a few carefully chosen questions can make a new topic easier to discuss. Readers should be able to move from the broad idea to a more detailed reference when they are ready.

[Explore technical groups]({{ '/working-groups/technical/' | relative_url }}) and [learn about participation]({{ '/working-groups/participation/' | relative_url }}).
