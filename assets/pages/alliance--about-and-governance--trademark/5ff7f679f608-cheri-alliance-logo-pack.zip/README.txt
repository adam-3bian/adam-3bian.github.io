CHERI Alliance website logo assets

This package restores the website logo download using the existing site assets.
Please follow the CHERI Alliance trademark policy: https://cheri-alliance.org/trademark/
